<?php

use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/user', [UserController::class, 'index'])->name('user.index');

Route::get('/posts', function () {
    $response = Http::get('https://jsonplaceholder.typicode.com/posts');
    $response1 = Http::get('https://jsonplaceholder.typicode.com/comments?postId=3');
    $posts1 = $response1->json();
    $posts = $response->json();
    return view('user', ['posts' => $posts], ['posts1' => $posts1]);
});